
-- ACADEMY.sql

CREATE DATABASE ACADEMY CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
use ACADEMY;

-- USUÁRIOS

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    birthdate DATE NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);



CREATE TABLE papeis_usuario (
    id_usuario INT NOT NULL,
    papel ENUM('admin','professor','aluno') NOT NULL,
    PRIMARY KEY(id_usuario, papel),
    FOREIGN KEY(id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);


-- CURSOS

CREATE TABLE cursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL UNIQUE,
    descricao TEXT,
    max_alunos_default INT NOT NULL DEFAULT 30 CHECK (max_alunos_default > 0)
);


-- TURMAS

CREATE TABLE turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_curso INT NOT NULL,
    id_professor INT NOT NULL,
    codigo VARCHAR(80),
    semestre VARCHAR(20),
    periodo_inicio DATE NOT NULL,
    periodo_fim DATE NOT NULL,
    max_alunos INT DEFAULT NULL CHECK (max_alunos > 0),
    CHECK (periodo_fim >= periodo_inicio),
    ativa BOOLEAN DEFAULT TRUE,
    archived BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_curso) REFERENCES cursos(id) ON DELETE CASCADE,
    FOREIGN KEY (id_professor) REFERENCES usuarios(id)
);


-- MATRICULAS

CREATE TABLE matriculas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_turma INT NOT NULL,
    id_aluno INT NOT NULL,
    data_matricula DATE DEFAULT (CURRENT_DATE),
    status ENUM('ENROLADO','REPROVADO','CONCLUIDO') DEFAULT 'ENROLADO',
    grade DECIMAL(5,2) DEFAULT NULL,
    UNIQUE(id_turma, id_aluno),
    FOREIGN KEY(id_turma) REFERENCES turmas(id) ON DELETE CASCADE,
    FOREIGN KEY(id_aluno) REFERENCES usuarios(id) ON DELETE CASCADE
);


-- MATERIAIS

CREATE TABLE materiais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_turma INT NOT NULL,
    titulo VARCHAR(200),
    conteudo TEXT,
    data_upload DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(id_turma) REFERENCES turmas(id) ON DELETE CASCADE
);


-- ATIVIDADES

CREATE TABLE atividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_turma INT NOT NULL,
    titulo VARCHAR(200),
    descricao TEXT,
    prazo DATETIME,
    max_grade DECIMAL(5,2) DEFAULT 10.00,
    FOREIGN KEY(id_turma) REFERENCES turmas(id) ON DELETE CASCADE
);


-- RESPOSTAS DE ATIVIDADES

CREATE TABLE respostas_atividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_atividade INT NOT NULL,
    id_aluno INT NOT NULL,
    resposta TEXT,
    data_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(id_atividade) REFERENCES atividades(id) ON DELETE CASCADE,
    FOREIGN KEY(id_aluno) REFERENCES usuarios(id) ON DELETE CASCADE
);


-- NOTAS

CREATE TABLE notas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_atividade INT NOT NULL,
    id_aluno INT NOT NULL,
    nota DECIMAL(5,2) NOT NULL,
    UNIQUE(id_atividade,id_aluno),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(id_atividade) REFERENCES atividades(id) ON DELETE CASCADE,
    FOREIGN KEY(id_aluno) REFERENCES usuarios(id) ON DELETE CASCADE
);


-- NOTIFICAÇÕES (mensagens interns)

CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    to_user_id INT NOT NULL,
    from_user_id INT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    seen BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (to_user_id) REFERENCES usuarios(id),
    FOREIGN KEY (from_user_id) REFERENCES usuarios(id)
);


-- PRIORITY ENROLL (alunos com prioridade por reprovação)

CREATE TABLE priority_enroll (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    course_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, course_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(id),
    FOREIGN KEY (course_id) REFERENCES cursos(id)
);


-- HISTÓRICO (médias finais)

CREATE TABLE historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_aluno INT NOT NULL,
    id_turma INT NOT NULL,
    media_final DECIMAL(5,2),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(id_aluno) REFERENCES usuarios(id),
    FOREIGN KEY(id_turma) REFERENCES turmas(id)
);


-- DATAS EXEMPLO (INSERÇÕES)


-- Usuários (admin, 2 professores, 3 alunos; um usuário com múltiplos papeis)
INSERT INTO usuarios (nome, email, senha, birthdate) VALUES
('Admin Master','admin@academy.br','137371420b171def204ab4acc26be32e:214ce7b41c850b7ec23917e0eb751c7a3f6779a259b64b9d17514641491a8ded','1980-01-01'),
('Jurair Professor','jurair.prof@academy.br','f16d99781f35e1d9c8d6892c21dd9367:ba168add2676a4d337080330e6aada03d5ba9b836457ac5aa4a2429163d0f661','1975-03-12'),
('Bruna Professor','bruna.prof@academy.br','29d69bb19864fe3b161e7bc6f9370787:2d733c0269520fb29d57baad3b6b0a6fc9e21fe4f069af28c35bad1dbecb98f9','1982-07-20'),
('Ana Aluna','ana.aluna@academy.br','fb4727270792284b69b389724a60df8f:183e945b58fa5c00b08f670f4db5cdcfdbba8201ac5799a22863a4d4a6cec5ea','2000-05-05'),
('Pedro Aluno','pedro.aluno@academy.br','3bbe6a73a73ce2f7b9c7dbfbb182daca:c832fb43b2d49fa142f49ee3637043cee1855df8d0d8ff658629f1e9c1528400','1999-11-11'),
('Carlos Mix','carlos.mix@academy.br','881440a6448fc209dc877c79d792d63d:25cdf4a90e2bc25fd97432202577b6c148a3760c0e6aecdcc68d711f28decb44','1995-06-06');

-- Papeis
INSERT INTO papeis_usuario (id_usuario, papel) VALUES
(1,'admin'),
(2,'professor'),
(3,'professor'),
(4,'aluno'),
(5,'aluno'),
(6,'professor'),
(6,'aluno'); -- Carlos é professor e aluno

-- Cursos
INSERT INTO cursos (nome, descricao, max_alunos_default) VALUES
('Programação Básica','Curso introdutório de programação',25),
('Banco de Dados','Teoria e prática com SQL',20);

-- Turmas
INSERT INTO turmas (id_curso, id_professor, codigo, semestre, periodo_inicio, periodo_fim, max_alunos) VALUES
(1,2,'PROG101-T1-2025','2025-1','2025-02-01','2025-06-30',20),
(1,3,'PROG101-T2-2025','2025-1','2025-02-01','2025-06-30',25),
(2,3,'DB201-T1-2025','2025-1','2025-02-01','2025-06-30',15);

-- Matrículas (algumas com notas)
INSERT INTO matriculas (id_turma, id_aluno, data_matricula, status) VALUES
(1,4,'2025-02-05','ENROLADO'),
(1,5,'2025-02-06','ENROLADO'),
(2,6,'2025-02-07','ENROLADO'),
(3,5,'2025-02-10','ENROLADO');

-- Materiais
INSERT INTO materiais (id_turma, titulo, conteudo) VALUES
(1,'Apostila 1','Introdução e conceitos básicos'),
(1,'Slides Aula 1','Slides com exemplos');

-- Atividades
INSERT INTO atividades (id_turma, titulo, descricao, prazo, max_grade) VALUES
(1,'Prova 1','Prova teórica','2025-03-15 23:59:00',10.0),
(1,'Trabalho 1','Entrega prática','2025-04-01 23:59:00',10.0),
(3,'Prova DB','Avaliação escrita','2025-03-20 23:59:00',10.0);

-- Notas
INSERT INTO notas (id_atividade, id_aluno, nota) VALUES
(1,4,6.5),
(1,5,4.0),
(2,4,8.0),
(3,5,9.0);

-- Observação: historico e priority_enrol vão ser populados por triggers/procedures.


-- VIEWS ÚTILS

-- notas por aluno e turma
CREATE OR REPLACE VIEW boletim AS
SELECT 
  u.id AS aluno_id,
  u.nome AS aluno_nome,
  t.id AS turma_id,
  t.codigo AS turma_codigo,
  a.id AS atividade_id,
  a.titulo AS atividade,
  n.nota,
  n.created_at AS nota_data
FROM notas n
JOIN usuarios u ON n.id_aluno = u.id
JOIN atividades a ON n.id_atividade = a.id
JOIN turmas t ON a.id_turma = t.id;

-- Alunos por turma
CREATE OR REPLACE VIEW alunos_por_turma AS
SELECT
  t.id AS turma_id,
  t.codigo AS turma_codigo,
  c.nome AS curso_nome,
  u.id AS aluno_id,
  u.nome AS aluno_nome
FROM matriculas m
JOIN turmas t ON m.id_turma = t.id
JOIN usuarios u ON m.id_aluno = u.id
JOIN cursos c ON t.id_curso = c.id;



-- PROCEDURE: calcular_media (inserir no historico se não existir)

DELIMITER //
CREATE PROCEDURE calcular_media(IN p_aluno INT, IN p_turma INT)
BEGIN
  DECLARE v_media DECIMAL(6,2);

  SELECT AVG(n.nota) INTO v_media
  FROM notas n
  JOIN atividades a ON n.id_atividade = a.id
  WHERE n.id_aluno = p_aluno
    AND a.id_turma = p_turma;

  IF v_media IS NOT NULL THEN
    -- evita duplicar entradas
    INSERT INTO historico (id_aluno, id_turma, media_final)
    SELECT p_aluno, p_turma, v_media
    FROM DUAL
    WHERE NOT EXISTS (
      SELECT 1 FROM historico h WHERE h.id_aluno = p_aluno AND h.id_turma = p_turma
    );
  END IF;
END //
DELIMITER ;


-- TRIGGER: before inserir matricula -> check capacidade e impedir professor de se inscrever em sua turma

DELIMITER //
CREATE TRIGGER trg_before_matricula
BEFORE INSERT ON matriculas
FOR EACH ROW
BEGIN
  DECLARE v_prof INT;

  DECLARE v_capacity INT;
  DECLARE v_count INT;

  IF NOT EXISTS (SELECT 1 FROM papeis_usuario WHERE id_usuario=NEW.id_aluno AND papel='aluno') OR NOT EXISTS (SELECT 1 FROM turmas WHERE id=NEW.id_turma AND ativa=TRUE AND archived=FALSE) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Aluno ou turma ativa invalida';
  END IF;
  -- impede professor de se matricular em sua própria turma
  SELECT id_professor INTO v_prof FROM turmas WHERE id = NEW.id_turma FOR UPDATE;
  IF v_prof = NEW.id_aluno THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Professor nao pode se matricular em sua propria turma.';
  END IF;

  -- obter capacidade (turma or default do curso)

  SELECT COALESCE(t.max_alunos, c.max_alunos_default) INTO v_capacity
  FROM turmas t JOIN cursos c ON t.id_curso = c.id
  WHERE t.id = NEW.id_turma;

  SELECT COUNT(*) INTO v_count FROM matriculas WHERE id_turma = NEW.id_turma AND status = 'ENROLADO';

  IF v_count >= v_capacity THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Matricula rejeitada: turma cheia.';
  END IF;
END //
DELIMITER ;


-- TRIGGER: depois de inseri nota -> verifica se todas atividades do aluno na turma tem nota; se sim, chama calcular_media

DELIMITER //
CREATE TRIGGER trg_after_insert_nota
AFTER INSERT ON notas
FOR EACH ROW
BEGIN
  DECLARE v_total_ativ INT;
  DECLARE v_total_notas INT;
  DECLARE v_turma INT;

  -- obtem a turma da atividade
  SELECT id_turma INTO v_turma FROM atividades WHERE id = NEW.id_atividade;

  -- quantas atividade existem na turma
  SELECT COUNT(*) INTO v_total_ativ FROM atividades WHERE id_turma = v_turma;

  -- quantas notas esse aluno tem para atividades dessa turma
  SELECT COUNT(DISTINCT n.id_atividade) INTO v_total_notas
  FROM notas n
  JOIN atividades a ON n.id_atividade = a.id
  WHERE n.id_aluno = NEW.id_aluno AND a.id_turma = v_turma;

  IF v_total_ativ > 0 AND v_total_notas >= v_total_ativ THEN
    CALL calcular_media(NEW.id_aluno, v_turma);
  END IF;
END //
DELIMITER ;



DELIMITER //
CREATE TRIGGER trg_turma_professor BEFORE INSERT ON turmas FOR EACH ROW
BEGIN
 IF NOT EXISTS (SELECT 1 FROM papeis_usuario WHERE id_usuario=NEW.id_professor AND papel='professor') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Professor invalido'; END IF;
END //
CREATE TRIGGER trg_nota_validar BEFORE INSERT ON notas FOR EACH ROW
BEGIN
 IF NOT EXISTS (SELECT 1 FROM atividades a JOIN matriculas m ON m.id_turma=a.id_turma WHERE a.id=NEW.id_atividade AND m.id_aluno=NEW.id_aluno AND NEW.nota BETWEEN 0 AND a.max_grade) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Nota ou matricula invalida'; END IF;
END //
DELIMITER ;
