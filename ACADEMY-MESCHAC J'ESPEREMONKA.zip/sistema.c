#include "db.h"
#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


static int ler(char *s, size_t n) { if (!fgets(s,n,stdin)) return 0; size_t k=strcspn(s,"\n"); if(s[k]) s[k]=0; else if(!feof(stdin)){int c;while((c=getchar())!='\n'&&c!=EOF){} puts("Entrada longa demais.");return 0;} return k>0; }
static int inteiro(int *v){char b[80],extra;return ler(b,sizeof b)&&sscanf(b,"%d %c",v,&extra)==1;}
static int decimal(float *v){char b[80],extra;return ler(b,sizeof b)&&sscanf(b,"%f %c",v,&extra)==1&&*v>=0&&*v<=100;}
//CONECTION COM BANCO DE DADOS

MYSQL *con;

// Conectar ao banco MySQL
void conectar() {
    con = db_connect();
    if (!con) exit(1);
}

// Desconectar do banco
void desconectar() {
    mysql_close(con);
}

// Executar comandos SQL sem retorno
int executar(const char *query) {
    if (mysql_query(con, query)) {
        printf("ERRO SQL: %s\n", mysql_error(con));
        return 0;
    }
    return 1;
}

// Executar SELECT e retornar resultado
MYSQL_RES *consultar(const char *query) {
    if (mysql_query(con, query)) {
        printf("ERRO SQL: %s\n", mysql_error(con));
        return NULL;
    }
    return mysql_store_result(con);
}

        
     
     //USUÁRIOS
// Cadastrar um novo usuário e atribuir papel
void cadastrarUsuario() {
    char nome[100], email[100], senha[100], papel[20];

    printf("Nome: ");
    if (!ler(nome,sizeof nome)) return;
    printf("Email: ");
    if (!ler(email,sizeof email)) return;
    printf("Senha: ");
    if (!ler(senha,sizeof senha)) return;
    printf("Papel (admin/professor/aluno): ");
    if (!ler(papel,sizeof papel)) return;

    if(strcmp(papel,"admin")&&strcmp(papel,"professor")&&strcmp(papel,"aluno")){puts("Papel inválido.");return;}
    char n[204],e[204],h[98],q[1000]; literal(nome,n);literal(email,e);
    if(!password_hash(senha,h)) return;
    if(!executar("START TRANSACTION")) return;
    snprintf(q,sizeof q,"INSERT INTO usuarios(nome,email,senha) VALUES(%s,%s,'%s')",n,e,h);
    if(!executar(q)){executar("ROLLBACK");return;}
    snprintf(q,sizeof q,"INSERT INTO papeis_usuario VALUES(%llu,'%s')",(unsigned long long)mysql_insert_id(con),papel);
    if(!executar(q)){executar("ROLLBACK");return;}
    if(executar("COMMIT")) puts("Usuário cadastrado!");
}

// Listar todos os usuários
void listarUsuarios() {
    MYSQL_RES *res = consultar("SELECT id,nome,email FROM usuarios");
    if (!res) return;
    MYSQL_ROW row;

    printf("\nID | Nome | Email\n");
    while ((row = mysql_fetch_row(res))) {
        printf("%s | %s | %s\n", row[0], row[1], row[2]);
    }
    mysql_free_result(res);
}

    
    // CURSOS
// Criar um novo curso
void criarCurso() {
    char nome[100];
    int max;

    printf("Nome do curso: ");
    if (!ler(nome,sizeof nome)) return;
    printf("Máximo de alunos: ");
    if (!inteiro(&max)) return;

    char q[400], n[204]; literal(nome,n); if(max<=0)return;
    snprintf(q,sizeof q,"INSERT INTO cursos (nome, max_alunos_default) VALUES (%s, %d)", n, max);
    if (executar(q)) printf("Curso criado!\n");
}

// Listar todos os cursos
void listarCursos() {
    MYSQL_RES *res = consultar("SELECT id,nome,max_alunos_default FROM cursos");
    if (!res) return;
    MYSQL_ROW r;

    printf("\nID | Curso | Máx\n");
    while ((r = mysql_fetch_row(res))) {
        printf("%s | %s | %s\n", r[0], r[1], r[2]);
    }
    mysql_free_result(res);
}

       
        // TURMAS
// Criar uma nova turma e associar ao professor
void criarTurma() {
    int curso, professor;
    char ini[20], fim[20];

    listarCursos();
    printf("ID do curso: ");
    if (!inteiro(&curso)) return;

    listarUsuarios();
    printf("ID do professor: ");
    if (!inteiro(&professor)) return;

    printf("Data início (AAAA-MM-DD): ");
    if (!ler(ini,sizeof ini)) return;
    printf("Data fim: ");
    if (!ler(fim,sizeof fim)) return;

    char q[500], a[44], b[44]; literal(ini,a);literal(fim,b);
    sprintf(q,
        "INSERT INTO turmas (id_curso, id_professor, periodo_inicio, periodo_fim) "
        "VALUES (%d, %d, CONVERT(%s USING utf8mb4), CONVERT(%s USING utf8mb4))", curso, professor, a, b);

    if (executar(q)) printf("Turma criada!\n");
}


// Listar todas as turmas ativas e seus professores
void listarTurmas() {
    MYSQL_RES *res = consultar(
        "SELECT t.id, c.nome, u.nome, t.ativa "
        "FROM turmas t "
        "JOIN cursos c ON t.id_curso = c.id "
        "JOIN usuarios u ON t.id_professor = u.id"
    );
    if (!res) return;
    MYSQL_ROW r;

    printf("\nID | Curso | Professor | Ativa\n");
    while ((r = mysql_fetch_row(res))) {
        printf("%s | %s | %s | %s\n", r[0], r[1], r[2], r[3]);
    }
    mysql_free_result(res);
}

       

        // MATRÍCULAS
// Verifica limite de alunos na  turma
// Matricular aluno em turma
void matricular() {
    int aluno, turma;

    listarUsuarios();
    printf("ID do aluno: ");
    if (!inteiro(&aluno)) return;

    listarTurmas();
    printf("ID da turma: ");
    if (!inteiro(&turma)) return;

    char q[500];
    sprintf(q,
        "INSERT INTO matriculas (id_turma, id_aluno) VALUES (%d, %d)",
        turma, aluno
    );

    if (executar(q)) printf("Aluno matriculado!\n");
}

        // NOTAS

// Registrar nota de aluno em atividade
void registrarNota() {
    int atividade, aluno;
    float nota;

    printf("ID atividade: ");
    if (!inteiro(&atividade)) return;
    printf("ID aluno: ");
    if (!inteiro(&aluno)) return;
    printf("Nota: ");
    if (!decimal(&nota)) return;

    char q[500];
    sprintf(q,
        "INSERT INTO notas (id_atividade, id_aluno, nota) "
        "VALUES (%d, %d, %f)",
        atividade, aluno, nota
    );
    if (executar(q)) printf("Nota registrada!\n");
}

        

        //FUNCIONALIDADES AVANÇADAS
// Média geral de notas por turma
void mediaPorTurma() {
    char query[500];
    sprintf(query,
        "SELECT t.id, c.nome, AVG(n.nota) as media "
        "FROM turmas t "
        "JOIN cursos c ON t.id_curso = c.id "
        "JOIN matriculas m ON m.id_turma = t.id "
        "JOIN atividades a ON a.id_turma=t.id JOIN notas n ON n.id_atividade=a.id AND n.id_aluno=m.id_aluno "
        "GROUP BY t.id, c.nome"
    );

    MYSQL_RES *res = consultar(query);
    if (!res) return;
    MYSQL_ROW r;

    printf("\nID Turma | Curso | Média\n");
    while ((r = mysql_fetch_row(res))) {
        printf("%s | %s | %.2f\n", r[0], r[1], atof(r[2]));
    }
    mysql_free_result(res);
}

// Alunos com desempenho abaixo do média (<5)
void alunosAbaixoMedia() {
    char query[500];
    sprintf(query,
        "SELECT u.nome, c.nome, AVG(n.nota) as media "
        "FROM usuarios u "
        "JOIN matriculas m ON u.id = m.id_aluno "
        "JOIN turmas t ON t.id = m.id_turma "
        "JOIN cursos c ON t.id_curso = c.id "
        "JOIN atividades a ON a.id_turma=t.id JOIN notas n ON n.id_atividade=a.id AND n.id_aluno=u.id "
        "GROUP BY u.id, u.nome, t.id, c.nome "
        "HAVING media < 5"
    );

    MYSQL_RES *res = consultar(query);
    if (!res) return;
    MYSQL_ROW r;

    printf("\nAluno | Curso | Média\n");
    while ((r = mysql_fetch_row(res))) {
        printf("%s | %s | %.2f\n", r[0], r[1], atof(r[2]));
    }
    mysql_free_result(res);
}

// Listar turmas ativas de um professor
void turmasAtivasProfessor() {
    int professor;
    listarUsuarios();
    printf("ID do professor: ");
    if (!inteiro(&professor)) return;

    char query[500];
    sprintf(query,
        "SELECT t.id, c.nome "
        "FROM turmas t "
        "JOIN cursos c ON t.id_curso = c.id "
        "WHERE t.id_professor=%d AND t.ativa=1",
        professor
    );

    MYSQL_RES *res = consultar(query);
    if (!res) return;
    MYSQL_ROW r;

    printf("\nID Turma | Curso\n");
    while ((r = mysql_fetch_row(res))) {
        printf("%s | %s\n", r[0], r[1]);
    }
    mysql_free_result(res);
}

// Prof com maior números de turmas ativas
void professorMaisTurmas() {
    char query[500];
    sprintf(query,
        "SELECT u.nome, COUNT(*) as total "
        "FROM turmas t "
        "JOIN usuarios u ON t.id_professor = u.id "
        "WHERE t.ativa=1 "
        "GROUP BY u.id, u.nome "
        "ORDER BY total DESC "
        "LIMIT 1"
    );

    MYSQL_RES *res = consultar(query);
    if (!res) return;
    MYSQL_ROW r;
    if ((r = mysql_fetch_row(res))) {
        printf("\nProfessor com mais turmas ativas: %s (%s turmas)\n", r[0], r[1]);
    }
    mysql_free_result(res);
}

// Top 3 turmas com melhor desempenho médio
void top3Turmas() {
    char query[600];
    sprintf(query,
        "SELECT t.id, c.nome, AVG(n.nota) as media "
        "FROM turmas t "
        "JOIN cursos c ON t.id_curso = c.id "
        "JOIN matriculas m ON m.id_turma = t.id "
        "JOIN atividades a ON a.id_turma=t.id JOIN notas n ON n.id_atividade=a.id AND n.id_aluno=m.id_aluno "
        "GROUP BY t.id, c.nome "
        "ORDER BY media DESC "
        "LIMIT 3"
    );

    MYSQL_RES *res = consultar(query);
    if (!res) return;
    MYSQL_ROW r;

    printf("\nID Turma | Curso | Média\n");
    while ((r = mysql_fetch_row(res))) {
        printf("%s | %s | %.2f\n", r[0], r[1], atof(r[2]));
    }
    mysql_free_result(res);
}

// Professores que também são alunos
void professoresTambemAlunos() {
    char query[500];
    sprintf(query,
        "SELECT u.nome "
        "FROM usuarios u "
        "JOIN papeis_usuario p1 ON u.id = p1.id_usuario AND p1.papel='professor' "
        "JOIN papeis_usuario p2 ON u.id = p2.id_usuario AND p2.papel='aluno'"
    );

    MYSQL_RES *res = consultar(query);
    if (!res) return;
    MYSQL_ROW r;

    printf("\nProfessores que também são alunos:\n");
    while ((r = mysql_fetch_row(res))) {
        printf("%s\n", r[0]);
    }
    mysql_free_result(res);
}

// Aluno quem fez mais cursos
void alunoMaisCursos() {
    char query[500];
    sprintf(query,
        "SELECT u.nome, COUNT(DISTINCT t.id_curso) as total "
        "FROM usuarios u "
        "JOIN matriculas m ON u.id = m.id_aluno "
        "JOIN turmas t ON t.id = m.id_turma "
        "GROUP BY u.id, u.nome "
        "ORDER BY total DESC "
        "LIMIT 1"
    );

    MYSQL_RES *res = consultar(query);
    if (!res) return;
    MYSQL_ROW r;
    if ((r = mysql_fetch_row(res))) {
        printf("\nAluno que fez mais cursos: %s (%s cursos)\n", r[0], r[1]);
    }
    mysql_free_result(res);
}

// Arquivar turmas que já passaram a data de término
void arquivarTurmas() {
    char query[300];
    sprintf(query,
        "UPDATE turmas SET ativa=0, archived=1 WHERE periodo_fim < CURDATE() AND ativa=1"
    );
    if (executar(query)) printf("Turmas passadas foram arquivadas.\n");
}

        // MENU PRINCIPAL
void menu() {
    int op;
    do {
        printf("\n******<< SISTEMA ACADÊMICO >>******\n");
        printf("1 - Cadastrar usuário\n");
        printf("2 - Listar usuários\n");
        printf("3 - Criar curso\n");
        printf("4 - Listar cursos\n");
        printf("5 - Criar turma\n");
        printf("6 - Listar turmas\n");
        printf("7 - Matricular aluno\n");
        printf("8 - Registrar nota\n");
        printf("9 - Média geral por turma\n");
        printf("10 - Alunos abaixo da média\n");
        printf("11 - Turmas ativas de professor\n");
        printf("12 - Professor com mais turmas\n");
        printf("13 - Top 3 turmas\n");
        printf("14 - Professores que também são alunos\n");
        printf("15 - Aluno que fez mais cursos\n");
        printf("16 - Arquivar turmas passadas\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        if (!inteiro(&op)) { if(feof(stdin)) return; op=-1; continue; }

        switch(op) {
            case 1: cadastrarUsuario(); break;
            case 2: listarUsuarios(); break;
            case 3: criarCurso(); break;
            case 4: listarCursos(); break;
            case 5: criarTurma(); break;
            case 6: listarTurmas(); break;
            case 7: matricular(); break;
            case 8: registrarNota(); break;
            case 9: mediaPorTurma(); break;
            case 10: alunosAbaixoMedia(); break;
            case 11: turmasAtivasProfessor(); break;
            case 12: professorMaisTurmas(); break;
            case 13: top3Turmas(); break;
            case 14: professoresTambemAlunos(); break;
            case 15: alunoMaisCursos(); break;
            case 16: arquivarTurmas(); break;
        }
    } while(op != 0);
}

        

        // MAIN
int main() {
    conectar();
    char email[151],senha[256];
    printf("Email administrativo: "); if(!ler(email,sizeof email)){desconectar();return 1;}
    printf("Senha: "); if(!ler(senha,sizeof senha)||!admin_login(con,email,senha)){puts("Acesso negado.");desconectar();return 1;}
    menu();
    desconectar();
    return 0;
}
