#include "db.h"
#include <assert.h>
int main(void){char a[98],b[98],l[100];assert(password_hash("teste",a));assert(password_hash("teste",b));assert(strcmp(a,b));assert(password_check("teste",a));assert(!password_check("errada",a));assert(!password_check("teste","invalido"));literal("a'b\\",l);assert(!strcmp(l,"X'6127625c'"));puts("Testes de hash e literal SQL: OK");return 0;}
