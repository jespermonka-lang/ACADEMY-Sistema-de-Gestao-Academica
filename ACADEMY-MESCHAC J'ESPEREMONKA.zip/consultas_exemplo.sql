USE ACADEMY;
-- EXEMPLOS DE CONSULTAS

-- 2.1 Quantidade de aluno em cada turma de um curso (example: curso_id = 1)
SELECT t.id AS turma_id, t.codigo, COUNT(m.id) AS qtd_alunos
FROM turmas t
LEFT JOIN matriculas m ON t.id = m.id_turma
WHERE t.id_curso = 1
GROUP BY t.id;

-- 2.2 Média geral de notas por turma de um curso (curso_id = 1)
SELECT t.id AS turma_id, t.codigo, AVG(n.nota) AS media_turma
FROM turmas t
JOIN atividades a ON a.id_turma = t.id
JOIN notas n ON n.id_atividade = a.id
WHERE t.id_curso = 1
GROUP BY t.id;

-- 2.3 Identificar alunos com desempenho abaixo da média (< 5)
SELECT u.id AS aluno_id, u.nome, AVG(n.nota) AS media_aluno
FROM usuarios u
JOIN notas n ON n.id_aluno = u.id
GROUP BY u.id
HAVING AVG(n.nota) < 5;

-- 2.4 Listar todas as turmas ativas de um determinado professor (professor id = 2)
SELECT * FROM turmas WHERE id_professor = 2 AND ativa = TRUE AND archived = FALSE;

-- 2.5 Indicar o professor com a maior número de turmas ativas
SELECT u.id, u.nome, COUNT(*) AS n_turmas
FROM usuarios u
JOIN turmas t ON u.id = t.id_professor
WHERE t.ativa = TRUE AND t.archived = FALSE
GROUP BY u.id
ORDER BY n_turmas DESC
LIMIT 1;

-- 2.6 Listar as 3 turmas que tiveram o melhor desempenho médio
SELECT t.id AS turma_id, t.codigo, AVG(n.nota) AS media
FROM turmas t
JOIN atividades a ON a.id_turma = t.id
JOIN notas n ON n.id_atividade = a.id
GROUP BY t.id
ORDER BY media DESC
LIMIT 3;

-- 2.7 Identificar profs que também são alunos
SELECT u.id, u.nome
FROM usuarios u
WHERE EXISTS (SELECT 1 FROM papeis_usuario p WHERE p.id_usuario = u.id AND p.papel = 'professor')
  AND EXISTS (SELECT 1 FROM papeis_usuario p2 WHERE p2.id_usuario = u.id AND p2.papel = 'aluno');

-- 2.8 Identificar qual aluno fez mais cursos (considerando matricula concluídas ou historico)
SELECT u.id, u.nome, COUNT(DISTINCT t.id_curso) AS cursos_feitos
FROM usuarios u
JOIN historico h ON h.id_aluno = u.id
JOIN turmas t ON h.id_turma = t.id
GROUP BY u.id
ORDER BY cursos_feitos DESC
LIMIT 1;

-- 2.9 Arquivar turmas (executar manulmente se quer)
-- UPDATE turmas SET archived = TRUE, ativa = FALSE WHERE periodo_fim < CURRENT_DATE() AND archived = FALSE;

