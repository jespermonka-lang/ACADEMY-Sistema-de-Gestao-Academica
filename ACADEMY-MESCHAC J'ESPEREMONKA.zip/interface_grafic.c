#include "db.h"
#include <gtk/gtk.h>
#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// VARIÁVEIS GLOBAIS
MYSQL *conn;
GtkWidget *window_login, *window_menu;
GtkWidget *entry_email, *entry_senha;


// CONEXÃO COM MYSQL
int conectar_mysql()
{
    conn = db_connect();
    return conn != NULL;
}


// FUNÇÕES AUXILIARES
void mostrar_erro_mysql(GtkWindow *parent)
{
    GtkWidget *dialog = gtk_message_dialog_new(parent, GTK_DIALOG_MODAL,
                                               GTK_MESSAGE_ERROR, GTK_BUTTONS_OK,
                                               "%s", mysql_error(conn));
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

int executar_query(const char *query)
{
    if (mysql_query(conn, query))
    {
        mostrar_erro_mysql(GTK_WINDOW(window_menu));
        return 0;
    }
    return 1;
}


// FUNÇÕES GENERICAS PARA TREEVIEW
GtkWidget* criar_treeview(int n_colunas, const char *const colunas[])
{
    GtkWidget *treeview = gtk_tree_view_new();
    for (int i = 0; i < n_colunas; i++)
    {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
        GtkTreeViewColumn *column = gtk_tree_view_column_new_with_attributes(colunas[i], renderer, "text", i, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
    }
    return treeview;
}


static int formulario(GtkWidget *tree, const char *title, const char **labels, int n, char values[][513]) {
 GtkWidget *d=gtk_dialog_new_with_buttons(title,GTK_WINDOW(gtk_widget_get_toplevel(tree)),GTK_DIALOG_MODAL,"Cancelar",GTK_RESPONSE_CANCEL,"Salvar",GTK_RESPONSE_OK,NULL);
 GtkWidget *grid=gtk_grid_new(); GtkWidget *entries[8]; gtk_container_add(GTK_CONTAINER(gtk_dialog_get_content_area(GTK_DIALOG(d))),grid);
 for(int i=0;i<n;i++){entries[i]=gtk_entry_new();gtk_entry_set_max_length(GTK_ENTRY(entries[i]),128);if(!strcmp(labels[i],"Senha"))gtk_entry_set_visibility(GTK_ENTRY(entries[i]),FALSE);gtk_grid_attach(GTK_GRID(grid),gtk_label_new(labels[i]),0,i,1,1);gtk_grid_attach(GTK_GRID(grid),entries[i],1,i,1,1);}
 gtk_widget_show_all(d);int ok=gtk_dialog_run(GTK_DIALOG(d))==GTK_RESPONSE_OK;
 if(ok)for(int i=0;i<n;i++){const char *v=gtk_entry_get_text(GTK_ENTRY(entries[i]));if(!*v||strlen(v)>512){ok=0;break;}g_strlcpy(values[i],v,513);}
 gtk_widget_destroy(d);return ok;
}
// CRUD - Usuarios
void carregar_usuarios(GtkWidget *treeview)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    GtkListStore *store;
    GtkTreeIter iter;

    store = gtk_list_store_new(5, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

    if (mysql_query(conn, "SELECT id, nome, email, birthdate, created_at FROM usuarios"))
    {
        mostrar_erro_mysql(GTK_WINDOW(gtk_widget_get_toplevel(treeview)));
        return;
    }
    res = mysql_store_result(conn);
    if (!res) { g_object_unref(store); return; }
    while ((row = mysql_fetch_row(res)))
    {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, atoi(row[0]),
                           1, row[1],
                           2, row[2],
                           3, row[3] ? row[3] : "",
                           4, row[4] ? row[4] : "",
                           -1);
    }
    mysql_free_result(res);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

void adicionar_usuario(GtkWidget *treeview) {
 const char *labels[]={"Nome","Email","Senha","Papel (admin/professor/aluno)"};
 char v[8][513], l[8][1028], q[9000];
 if(!formulario(treeview,"Adicionar",labels,4,v))return;
 for(int i=0;i<4;i++)literal(v[i],l[i]);
 char hash[98]; if(strcmp(v[3],"admin")&&strcmp(v[3],"professor")&&strcmp(v[3],"aluno"))return;
 if(!password_hash(v[2],hash)||!executar_query("START TRANSACTION"))return;
 snprintf(q,sizeof q,"INSERT INTO usuarios(nome,email,senha) VALUES(%s,%s,'%s')",l[0],l[1],hash);
 if(!executar_query(q)){executar_query("ROLLBACK");return;}
 snprintf(q,sizeof q,"INSERT INTO papeis_usuario VALUES(%llu,CONVERT(%s USING utf8mb4))",(unsigned long long)mysql_insert_id(conn),l[3]);
 if(!executar_query(q)){executar_query("ROLLBACK");return;} if(!executar_query("COMMIT"))return;
 carregar_usuarios(treeview);
}

void excluir_usuario(GtkWidget *treeview)
{
    GtkTreeSelection *sel = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gint id;
    if (gtk_tree_selection_get_selected(sel, &model, &iter))
    {
        gtk_tree_model_get(model, &iter, 0, &id, -1);
        char query[256];
        sprintf(query, "DELETE FROM usuarios WHERE id=%d", id);
        if (!executar_query(query)) return;
        carregar_usuarios(treeview);
    }
}

// CRUD - Cursos
void carregar_cursos(GtkWidget *treeview)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    GtkListStore *store;
    GtkTreeIter iter;
    store = gtk_list_store_new(4, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);

    if (mysql_query(conn, "SELECT id, nome, descricao, max_alunos_default FROM cursos"))
    { mostrar_erro_mysql(GTK_WINDOW(gtk_widget_get_toplevel(treeview))); return; }

    res = mysql_store_result(conn);
    if (!res) { g_object_unref(store); return; }
    while ((row = mysql_fetch_row(res)))
    {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, atoi(row[0]),
                           1, row[1],
                           2, row[2] ? row[2] : "",
                           3, atoi(row[3]),
                           -1);
    }
    mysql_free_result(res);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

void adicionar_curso(GtkWidget *treeview) {
 const char *labels[]={"Nome","Descrição","Máximo de alunos"};
 char v[8][513], l[8][1028], q[9000];
 if(!formulario(treeview,"Adicionar",labels,3,v))return;
 for(int i=0;i<3;i++)literal(v[i],l[i]);
 snprintf(q,sizeof q,"INSERT INTO cursos(nome,descricao,max_alunos_default) VALUES(CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4))",l[0],l[1],l[2]);
 if(!executar_query(q))return;
 carregar_cursos(treeview);
}

void excluir_curso(GtkWidget *treeview)
{
    GtkTreeSelection *sel = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gint id;
    if (gtk_tree_selection_get_selected(sel, &model, &iter))
    {
        gtk_tree_model_get(model, &iter, 0, &id, -1);
        char query[256];
        sprintf(query, "DELETE FROM cursos WHERE id=%d", id);
        if (!executar_query(query)) return;
        carregar_cursos(treeview);
    }
}



// CRUD - Turmas
void carregar_turmas(GtkWidget *treeview)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    GtkListStore *store;
    GtkTreeIter iter;

    store = gtk_list_store_new(8, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING,
                               G_TYPE_STRING, G_TYPE_STRING, G_TYPE_BOOLEAN, G_TYPE_BOOLEAN);

    if (mysql_query(conn, "SELECT id, id_curso, id_professor, codigo, semestre, periodo_inicio, ativa, archived FROM turmas"))
    { mostrar_erro_mysql(GTK_WINDOW(gtk_widget_get_toplevel(treeview))); return; }

    res = mysql_store_result(conn);
    if (!res) { g_object_unref(store); return; }
    while ((row = mysql_fetch_row(res)))
    {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, atoi(row[0]),
                           1, atoi(row[1]),
                           2, atoi(row[2]),
                           3, row[3] ? row[3] : "",
                           4, row[4] ? row[4] : "",
                           5, row[5] ? row[5] : "",
                           6, atoi(row[6]),
                           7, atoi(row[7]),
                           -1);
    }
    mysql_free_result(res);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

void adicionar_turma(GtkWidget *treeview) {
 const char *labels[]={"ID curso","ID professor","Código","Início AAAA-MM-DD","Fim AAAA-MM-DD"};
 char v[8][513], l[8][1028], q[9000];
 if(!formulario(treeview,"Adicionar",labels,5,v))return;
 for(int i=0;i<5;i++)literal(v[i],l[i]);
 snprintf(q,sizeof q,"INSERT INTO turmas(id_curso,id_professor,codigo,periodo_inicio,periodo_fim) VALUES(CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4))",l[0],l[1],l[2],l[3],l[4]);
 if(!executar_query(q))return;
 carregar_turmas(treeview);
}

void excluir_turma(GtkWidget *treeview)
{
    GtkTreeSelection *sel = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gint id;
    if (gtk_tree_selection_get_selected(sel, &model, &iter))
    {
        gtk_tree_model_get(model, &iter, 0, &id, -1);
        char query[256];
        sprintf(query, "DELETE FROM turmas WHERE id=%d", id);
        if (!executar_query(query)) return;
        carregar_turmas(treeview);
    }
}


// CRUD - Matriculas
void carregar_matriculas(GtkWidget *treeview)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    GtkListStore *store;
    GtkTreeIter iter;
    store = gtk_list_store_new(5, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);

    if (mysql_query(conn, "SELECT id,id_turma,id_aluno,data_matricula,status FROM matriculas"))
    { mostrar_erro_mysql(GTK_WINDOW(gtk_widget_get_toplevel(treeview))); return; }

    res = mysql_store_result(conn);
    if (!res) { g_object_unref(store); return; }
    while ((row = mysql_fetch_row(res)))
    {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store,&iter,
                           0, atoi(row[0]),
                           1, atoi(row[1]),
                           2, atoi(row[2]),
                           3, row[3]?row[3]:"",
                           4, row[4]?row[4]:"",
                           -1);
    }
    mysql_free_result(res);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview),GTK_TREE_MODEL(store));
    g_object_unref(store);
}

void adicionar_matricula(GtkWidget *treeview) {
 const char *labels[]={"ID turma","ID aluno"};
 char v[8][513], l[8][1028], q[9000];
 if(!formulario(treeview,"Adicionar",labels,2,v))return;
 for(int i=0;i<2;i++)literal(v[i],l[i]);
 snprintf(q,sizeof q,"INSERT INTO matriculas(id_turma,id_aluno) VALUES(CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4))",l[0],l[1]);
 if(!executar_query(q))return;
 carregar_matriculas(treeview);
}

void excluir_matricula(GtkWidget *treeview)
{
    GtkTreeSelection *sel=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gint id;
    if(gtk_tree_selection_get_selected(sel,&model,&iter))
    {
        gtk_tree_model_get(model,&iter,0,&id,-1);
        char query[256];
        sprintf(query,"DELETE FROM matriculas WHERE id=%d",id);
        if(!executar_query(query)) return;
        carregar_matriculas(treeview);
    }
}

// CRUD - Materiais
void carregar_materiais(GtkWidget *treeview)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    GtkListStore *store;
    GtkTreeIter iter;
    store=gtk_list_store_new(4,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
    if(mysql_query(conn,"SELECT id,id_turma,titulo,conteudo FROM materiais")) { mostrar_erro_mysql(GTK_WINDOW(gtk_widget_get_toplevel(treeview))); return; }
    res=mysql_store_result(conn);
    if (!res) { g_object_unref(store); return; }
    while((row=mysql_fetch_row(res)))
    {
        gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,
                           0,atoi(row[0]),
                           1,atoi(row[1]),
                           2,row[2]?row[2]:"",
                           3,row[3]?row[3]:"",
                           -1);
    }
    mysql_free_result(res);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview),GTK_TREE_MODEL(store));
    g_object_unref(store);
}
void adicionar_material(GtkWidget *treeview) {
 const char *labels[]={"ID turma","Título","Conteúdo"};
 char v[8][513], l[8][1028], q[9000];
 if(!formulario(treeview,"Adicionar",labels,3,v))return;
 for(int i=0;i<3;i++)literal(v[i],l[i]);
 snprintf(q,sizeof q,"INSERT INTO materiais(id_turma,titulo,conteudo) VALUES(CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4))",l[0],l[1],l[2]);
 if(!executar_query(q))return;
 carregar_materiais(treeview);
}
void excluir_material(GtkWidget *treeview)
{
    GtkTreeSelection *sel=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gint id;
    if(gtk_tree_selection_get_selected(sel,&model,&iter))
    {
        gtk_tree_model_get(model,&iter,0,&id,-1);
        char query[256];
        sprintf(query,"DELETE FROM materiais WHERE id=%d",id);
        if(!executar_query(query)) return;
        carregar_materiais(treeview);
    }
}


// CRUD - Atividades
void carregar_atividades(GtkWidget *treeview)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    GtkListStore *store;
    GtkTreeIter iter;
    store=gtk_list_store_new(5,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
    if(mysql_query(conn,"SELECT id,id_turma,titulo,descricao,prazo FROM atividades")) { mostrar_erro_mysql(GTK_WINDOW(gtk_widget_get_toplevel(treeview))); return; }
    res=mysql_store_result(conn);
    if (!res) { g_object_unref(store); return; }
    while((row=mysql_fetch_row(res)))
    {
        gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,
                           0,atoi(row[0]),
                           1,atoi(row[1]),
                           2,row[2]?row[2]:"",
                           3,row[3]?row[3]:"",
                           4,row[4]?row[4]:"",
                           -1);
    }
    mysql_free_result(res);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview),GTK_TREE_MODEL(store));
    g_object_unref(store);
}
void adicionar_atividade(GtkWidget *treeview) {
 const char *labels[]={"ID turma","Título","Descrição","Prazo AAAA-MM-DD HH:MM:SS"};
 char v[8][513], l[8][1028], q[9000];
 if(!formulario(treeview,"Adicionar",labels,4,v))return;
 for(int i=0;i<4;i++)literal(v[i],l[i]);
 snprintf(q,sizeof q,"INSERT INTO atividades(id_turma,titulo,descricao,prazo) VALUES(CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4))",l[0],l[1],l[2],l[3]);
 if(!executar_query(q))return;
 carregar_atividades(treeview);
}
void excluir_atividade(GtkWidget *treeview)
{
    GtkTreeSelection *sel=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gint id;
    if(gtk_tree_selection_get_selected(sel,&model,&iter))
    {
        gtk_tree_model_get(model,&iter,0,&id,-1);
        char query[256];
        sprintf(query,"DELETE FROM atividades WHERE id=%d",id);
        if(!executar_query(query)) return;
        carregar_atividades(treeview);
    }
}


// CRUD - Notas
void carregar_notas(GtkWidget *treeview)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    GtkListStore *store;
    GtkTreeIter iter;
    store=gtk_list_store_new(4,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_DOUBLE);
    if(mysql_query(conn,"SELECT id,id_atividade,id_aluno,nota FROM notas")) { mostrar_erro_mysql(GTK_WINDOW(gtk_widget_get_toplevel(treeview))); return; }
    res=mysql_store_result(conn);
    if (!res) { g_object_unref(store); return; }
    while((row=mysql_fetch_row(res)))
    {
        gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,
                           0,atoi(row[0]),
                           1,atoi(row[1]),
                           2,atoi(row[2]),
                           3,atof(row[3]),
                           -1);
    }
    mysql_free_result(res);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview),GTK_TREE_MODEL(store));
    g_object_unref(store);
}
void adicionar_nota(GtkWidget *treeview) {
 const char *labels[]={"ID atividade","ID aluno","Nota"};
 char v[8][513], l[8][1028], q[9000];
 if(!formulario(treeview,"Adicionar",labels,3,v))return;
 for(int i=0;i<3;i++)literal(v[i],l[i]);
 snprintf(q,sizeof q,"INSERT INTO notas(id_atividade,id_aluno,nota) VALUES(CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4),CONVERT(%s USING utf8mb4))",l[0],l[1],l[2]);
 if(!executar_query(q))return;
 carregar_notas(treeview);
}
void excluir_nota(GtkWidget *treeview)
{
    GtkTreeSelection *sel=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gint id;
    if(gtk_tree_selection_get_selected(sel,&model,&iter))
    {
        gtk_tree_model_get(model,&iter,0,&id,-1);
        char query[256];
        sprintf(query,"DELETE FROM notas WHERE id=%d",id);
        if(!executar_query(query)) return;
        carregar_notas(treeview);
    }
}


// FUNÇÃO PARA CRIAR JANELA CRUD
typedef struct {const char *title; const char *cols[9]; int n; void (*load)(GtkWidget*);void (*add)(GtkWidget*);void (*del)(GtkWidget*);} Tela;
static const Tela telas[]={
 {"Usuarios",{"ID","Nome","Email","Nascimento","Criado"},5,carregar_usuarios,adicionar_usuario,excluir_usuario},
 {"Cursos",{"ID","Nome","Descrição","Máximo"},4,carregar_cursos,adicionar_curso,excluir_curso},
 {"Turmas",{"ID","Curso","Professor","Código","Semestre","Início","Ativa","Arquivada"},8,carregar_turmas,adicionar_turma,excluir_turma},
 {"Matriculas",{"ID","Turma","Aluno","Data","Status"},5,carregar_matriculas,adicionar_matricula,excluir_matricula},
 {"Materiais",{"ID","Turma","Título","Conteúdo"},4,carregar_materiais,adicionar_material,excluir_material},
 {"Atividades",{"ID","Turma","Título","Descrição","Prazo"},5,carregar_atividades,adicionar_atividade,excluir_atividade},
 {"Notas",{"ID","Atividade","Aluno","Nota"},4,carregar_notas,adicionar_nota,excluir_nota}};
static void acao(GtkButton *button,gpointer data){GtkWidget *tree=data;const Tela *t=g_object_get_data(G_OBJECT(tree),"tela");if(!strcmp(gtk_button_get_label(button),"Adicionar"))t->add(tree);else{GtkWidget *d=gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(tree)),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_YES_NO,"Excluir registro selecionado? Registros associados podem ser afetados.");int r=gtk_dialog_run(GTK_DIALOG(d));gtk_widget_destroy(d);if(r==GTK_RESPONSE_YES)t->del(tree);}}
static void abrir_tela(GtkButton *button,gpointer data){(void)button;const Tela *t=data;GtkWidget *win=gtk_window_new(GTK_WINDOW_TOPLEVEL);gtk_window_set_title(GTK_WINDOW(win),t->title);gtk_window_set_default_size(GTK_WINDOW(win),800,450);gtk_window_set_transient_for(GTK_WINDOW(win),GTK_WINDOW(window_menu));gtk_window_set_destroy_with_parent(GTK_WINDOW(win),TRUE);GtkWidget *box=gtk_box_new(GTK_ORIENTATION_VERTICAL,5);gtk_container_add(GTK_CONTAINER(win),box);GtkWidget *tree=criar_treeview(t->n,t->cols);g_object_set_data(G_OBJECT(tree),"tela",(gpointer)t);GtkWidget *scroll=gtk_scrolled_window_new(NULL,NULL);gtk_container_add(GTK_CONTAINER(scroll),tree);gtk_box_pack_start(GTK_BOX(box),scroll,TRUE,TRUE,0);GtkWidget *add=gtk_button_new_with_label("Adicionar"),*del=gtk_button_new_with_label("Excluir");gtk_box_pack_start(GTK_BOX(box),add,FALSE,FALSE,0);gtk_box_pack_start(GTK_BOX(box),del,FALSE,FALSE,0);g_signal_connect(add,"clicked",G_CALLBACK(acao),tree);g_signal_connect(del,"clicked",G_CALLBACK(acao),tree);t->load(tree);gtk_widget_show_all(win);}
// MENU PRINCIPAL
void abrir_menu_principal()
{
    window_menu = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window_menu,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    gtk_window_set_title(GTK_WINDOW(window_menu), "Menu Principal");
    gtk_window_set_default_size(GTK_WINDOW(window_menu), 400, 400);

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window_menu), vbox);

    GtkWidget *btn1 = gtk_button_new_with_label("Usuarios");
    GtkWidget *btn2 = gtk_button_new_with_label("Cursos");
    GtkWidget *btn3 = gtk_button_new_with_label("Turmas");
    GtkWidget *btn4 = gtk_button_new_with_label("Matriculas");
    GtkWidget *btn5 = gtk_button_new_with_label("Materiais");
    GtkWidget *btn6 = gtk_button_new_with_label("Atividades");
    GtkWidget *btn7 = gtk_button_new_with_label("Notas");
    GtkWidget *btn8 = gtk_button_new_with_label("Sair");

    g_signal_connect(btn1,"clicked",G_CALLBACK(abrir_tela),(gpointer)&telas[0]);
    g_signal_connect(btn2,"clicked",G_CALLBACK(abrir_tela),(gpointer)&telas[1]);
    g_signal_connect(btn3,"clicked",G_CALLBACK(abrir_tela),(gpointer)&telas[2]);
    g_signal_connect(btn4,"clicked",G_CALLBACK(abrir_tela),(gpointer)&telas[3]);
    g_signal_connect(btn5,"clicked",G_CALLBACK(abrir_tela),(gpointer)&telas[4]);
    g_signal_connect(btn6,"clicked",G_CALLBACK(abrir_tela),(gpointer)&telas[5]);
    g_signal_connect(btn7,"clicked",G_CALLBACK(abrir_tela),(gpointer)&telas[6]);
    g_signal_connect(btn8,"clicked",G_CALLBACK(gtk_main_quit),NULL);

    gtk_box_pack_start(GTK_BOX(vbox),btn1,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(vbox),btn2,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(vbox),btn3,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(vbox),btn4,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(vbox),btn5,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(vbox),btn6,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(vbox),btn7,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(vbox),btn8,FALSE,FALSE,5);

    gtk_widget_show_all(window_menu);
}


// LOGIN
void verificar_login(GtkButton *button, gpointer data)
{
    (void)button; (void)data;
    const char *email = gtk_entry_get_text(GTK_ENTRY(entry_email));
    const char *senha = gtk_entry_get_text(GTK_ENTRY(entry_senha));
    if(admin_login(conn,email,senha))
    {
        gtk_widget_hide(window_login);
        abrir_menu_principal();
    }
    else
    {
        GtkWidget *dialog=gtk_message_dialog_new(GTK_WINDOW(window_login),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Email ou senha incorretos!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}

void criar_tela_login()
{
    window_login = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window_login,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    gtk_window_set_title(GTK_WINDOW(window_login), "Login");
    gtk_window_set_default_size(GTK_WINDOW(window_login), 300, 200);

    GtkWidget *grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window_login),grid);

    GtkWidget *label1=gtk_label_new("Email:");
    GtkWidget *label2=gtk_label_new("Senha:");
    entry_email=gtk_entry_new();
    entry_senha=gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(entry_senha),FALSE);

    GtkWidget *btn_login=gtk_button_new_with_label("Entrar");
    g_signal_connect(btn_login,"clicked",G_CALLBACK(verificar_login),NULL);

    gtk_grid_attach(GTK_GRID(grid),label1,0,0,1,1);
    gtk_grid_attach(GTK_GRID(grid),entry_email,1,0,1,1);
    gtk_grid_attach(GTK_GRID(grid),label2,0,1,1,1);
    gtk_grid_attach(GTK_GRID(grid),entry_senha,1,1,1,1);
    gtk_grid_attach(GTK_GRID(grid),btn_login,1,2,1,1);

    gtk_widget_show_all(window_login);
}


// MAIN
int main(int argc,char **argv)
{
    gtk_init(&argc,&argv);
    if(!conectar_mysql()){ printf("Falha ao conectar ao banco de dados.\n"); return 1; }
    criar_tela_login();
    gtk_main();
    mysql_close(conn);
    return 0;
}


// para compilar : gcc `mysql_config --cflags` `pkg-config --cflags gtk+-3.0` -o interface_grafic interface_grafic.c `mysql_config --libs` `pkg-config --libs gtk+-3.0` -Wall
// dps é just : ./interface_grafic