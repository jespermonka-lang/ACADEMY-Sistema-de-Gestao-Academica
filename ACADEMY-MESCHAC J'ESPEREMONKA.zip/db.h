#ifndef ACADEMY_DB_H
#define ACADEMY_DB_H
#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/crypto.h>
static inline const char *env_or(const char *key,const char *fallback){const char *v=getenv(key);return v?v:fallback;}
static inline MYSQL *db_connect(void){MYSQL *c=mysql_init(NULL);if(!c)return NULL;mysql_options(c,MYSQL_SET_CHARSET_NAME,"utf8mb4");if(!mysql_real_connect(c,env_or("ACADEMY_DB_HOST","localhost"),env_or("ACADEMY_DB_USER","academy_app"),env_or("ACADEMY_DB_PASSWORD",""),"ACADEMY",3306,NULL,0)){fprintf(stderr,"MySQL: %s\n",mysql_error(c));mysql_close(c);return NULL;}return c;}
/* Literal hexadecimal: dados nunca são interpretados como sintaxe SQL. */
static inline void literal(const char *s,char *out){static const char h[]="0123456789abcdef";*out++='X';*out++='\'';while(*s){unsigned char c=(unsigned char)*s++;*out++=h[c>>4];*out++=h[c&15];}*out++='\'';*out=0;}
static inline void hex_encode(const unsigned char *p,size_t n,char *out){for(size_t i=0;i<n;i++)snprintf(out+2*i,3,"%02x",p[i]);}
static inline int password_hash(const char *pw,char out[98]){unsigned char salt[16],key[32];if(RAND_bytes(salt,16)!=1||!PKCS5_PBKDF2_HMAC(pw,-1,salt,16,600000,EVP_sha256(),32,key))return 0;hex_encode(salt,16,out);out[32]=':';hex_encode(key,32,out+33);return 1;}
static inline int password_check(const char *pw,const char *hash){unsigned char salt[16],key[32];char encoded[65];if(!hash||strlen(hash)!=97||hash[32]!=':')return 0;for(int i=0;i<16;i++){unsigned int v;if(sscanf(hash+2*i,"%2x",&v)!=1)return 0;salt[i]=(unsigned char)v;}if(!PKCS5_PBKDF2_HMAC(pw,-1,salt,16,600000,EVP_sha256(),32,key))return 0;hex_encode(key,32,encoded);return CRYPTO_memcmp(encoded,hash+33,64)==0;}
static inline int admin_login(MYSQL *c,const char *email,const char *pw){if(strlen(email)>150)return 0;char e[304],q[600];literal(email,e);snprintf(q,sizeof q,"SELECT u.senha FROM usuarios u JOIN papeis_usuario p ON p.id_usuario=u.id WHERE u.email=%s AND p.papel='admin'",e);if(mysql_query(c,q))return 0;MYSQL_RES *r=mysql_store_result(c);if(!r)return 0;MYSQL_ROW row=mysql_fetch_row(r);int ok=row&&password_check(pw,row[0]);mysql_free_result(r);return ok;}
#endif
